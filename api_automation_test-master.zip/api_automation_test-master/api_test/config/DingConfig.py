# -*- coding: utf-8 -*-

# @Time    : 2019/12/13 22:12

# @Author  : litao

# @Project : api_automation_test

# @FileName: DingConfig.py

# @Software: PyCharm

APPID = 'dingoapfjxo0dzezwe47sy'

APPSECRET = '5_6b7h8eogyS1kstGWigpmuQbQUd585Vlc9ftjlcz48_avtLGQ5glolATWl3HFOf'
